from pymaze import maze, agent
import heapq


class SearchSolution:
    """
    A class used to represent a search solution in a maze using different algorithms.

    This class takes a maze and an agent and applies a search method (BFS, DFS, 
    Greedy Search, or A* search) to find a path to the goal.

    Attributes:
        __method: The search method to be used (BFS, DFS, GS, AStar)
        __fringe: The data structure to store a queue of nodes to be visited
        __path_fringe: The queue of all paths explored by the search
        __expanded_nodes: The list of all expanded nodes during the search
        __goal_position: The position of the goal
        __agent_position: The starting position of the agent
        __maze_map: The maze map, represented as a dictionary
                    where the keys are the cell positions and the values are
                    the information of the four walls of that cell in four directions
        __maze_grid: The grid of maze, represented as a list of cell positions
        __heuristic_map: The maze map with the same key set as that of __maze_map
                            and the values being the Manhattan heuristic values of the corresponding cells
        __depth: The depth in the search tree where the solution is found
        __num_created: The counter of nodes created in the search graph
        __num_expanded: The counter of nodes expanded in the search graph
        __max_fringe: The maximum size of the fringe at any point during the search
    """

    def __init__(self, m: maze, a: agent, method: str):
        """
        Constructs the necessary attributes for the SearchSolution object.

        Args:
            m: The maze object to be solved.
            a: The agent that will navigate through the maze.
            method: The search algorithm to be used. Should be one of the following:
                "BFS": Breadth-First Search,
                "DFS": Depth-First Search,
                "GS": Greedy Search,
                "AStar": A* Search

        Raises:
            ValueError: If the method provided is not one of the supported algorithms.
        """
        self.__method = method
        self.__fringe = []
        self.__path_fringe = []
        self.__expanded_nodes = set()
        self.__goal_position = m._goal
        self.__agent_position = a.position
        self.__solution_path = []
        self.__maze_map = m.maze_map
        self.__maze_grid = m.grid
        self.__heuristic_map = self.heuristics()

        self.__depth = -1
        self.__num_created = 0
        self.__num_expanded = 0
        self.__max_fringe = 0

    def search(self):
        """
        Executes the search based on the selected method.

        Returns:
            A string representing the path found by the search algorithm. The string contains
            the direction movements from the start to the goal in the maze.

        Raises:
            ValueError: If the method specified is not supported.
        """
        search_methods = {
            "BFS": self.__bfs,
            "DFS": self.__dfs,
            "GS": self.__gs,
            "AStar": self.__a_star
        }

        search_function = search_methods[self.__method]

        if search_function is None:
            raise ValueError(f"Unknown search method: {self.__method}")

        return search_function()

    def evaluate(self) -> dict[str, int]:
        """
        Evaluates the search algorithm by collecting the following metrics:
        depth of search tree,
        number of nodes created,
        number of nodes expanded, and
        maximum size of the fringe at any point in the search.

        Returns:
            A dictionary containing the evaluation metrics.
        """
        if not self.__solution_path:
            self.__depth = -1
            self.__num_created = 0
            self.__num_expanded = 0
            self.__max_fringe = 0

        return {
            'depth': self.__depth,
            'numCreated': self.__num_created,
            'numExpanded': self.__num_expanded,
            'maxFringe': self.__max_fringe
        }

    def __bfs(self) -> list[tuple]:
        """
        Performs Breadth-First Graph Search (BFS) on the maze.

        Returns:
            A list of cells representing the path found by the search algorithm from the start to the goal in the maze.
        """
        self.__fringe.append(self.__agent_position)
        self.__path_fringe.append([self.__agent_position])
        self.__num_created += 1
        self.__max_fringe = len(self.__fringe)

        while self.__fringe:
            current_node = self.__fringe.pop(0)
            current_path = self.__path_fringe.pop(0)

            if current_node not in self.__expanded_nodes:
                self.__expanded_nodes.add(current_node)
                self.__num_expanded += 1

                if current_node == self.__goal_position:
                    self.__depth = len(current_path)
                    self.__solution_path = current_path
                    return self.__solution_path

                for direction, status in self.__maze_map[current_node].items():
                    if status == 1:
                        adjacent_node = self.adjacent(current_node, direction)

                        new_path = list(current_path)
                        new_path.append(adjacent_node)
                        self.__path_fringe.append(new_path)
                        self.__fringe.append(adjacent_node)
                        self.__num_created += 1

                        if len(self.__fringe) > self.__max_fringe:
                            self.__max_fringe = len(self.__fringe)

        return self.__solution_path

    def __dfs(self) -> list[tuple[int, int]]:
        """
        Perform Depth-First Graph Search (DFS) on the maze.

        Returns:
            A list of cells representing the path found by the search algorithm from the start to the goal in the maze.
        """
        self.__fringe.append(self.__agent_position)
        self.__path_fringe.append([self.__agent_position])
        self.__num_created += 1
        self.__max_fringe = len(self.__fringe)

        while self.__fringe:
            current_node = self.__fringe.pop()
            current_path = self.__path_fringe.pop()

            if current_node not in self.__expanded_nodes:
                self.__expanded_nodes.add(current_node)
                self.__num_expanded += 1

                if current_node == self.__goal_position:
                    self.__depth = len(current_path)
                    self.__solution_path = current_path
                    return self.__solution_path

                for direction, status in self.__maze_map[current_node].items():
                    if status == 1:
                        adjacent_node = self.adjacent(current_node, direction)

                        new_path = list(current_path)
                        new_path.append(adjacent_node)
                        self.__path_fringe.append(new_path)
                        self.__fringe.append(adjacent_node)
                        self.__num_created += 1

                        if len(self.__fringe) > self.__max_fringe:
                            self.__max_fringe = len(self.__fringe)

        return self.__solution_path

    def __gs(self) -> list[tuple[int, int]]:
        """
        Perform Greedy Graph Search (GS) on the maze.

        Returns:
            A list of cells representing the path found by the search algorithm from the start to the goal in the maze.
        """
        solution_path = []
        parent = {self.__agent_position: None}
        heapq.heappush(self.__fringe, (self.__heuristic_map[self.__agent_position], self.__agent_position))
        self.__num_created += 1
        self.__max_fringe = len(self.__fringe)

        while self.__fringe:
            current_node = heapq.heappop(self.__fringe)[1]

            if current_node not in self.__expanded_nodes:
                self.__expanded_nodes.add(current_node)
                self.__num_expanded += 1

                if current_node == self.__goal_position:
                    while current_node is not None:
                        solution_path.append(current_node)
                        current_node = parent[current_node]
                    solution_path.reverse()
                    self.__depth = len(solution_path)
                    self.__solution_path = solution_path
                    return self.__solution_path

                for direction, status in self.__maze_map[current_node].items():
                    if status == 1:
                        adjacent_node = self.adjacent(current_node, direction)

                        if adjacent_node not in self.__expanded_nodes and adjacent_node not in parent:
                            parent[adjacent_node] = current_node
                            heapq.heappush(self.__fringe, (self.__heuristic_map[adjacent_node], adjacent_node))
                            self.__num_created += 1

                            if len(self.__fringe) > self.__max_fringe:
                                self.__max_fringe = len(self.__fringe)

        return self.__solution_path

    def __a_star(self) -> list[tuple[int, int]]:
        """
        Perform A* Graph Search on the maze.

        Returns:
            A list of cells representing the path found by the search algorithm from the start to the goal in the maze.
        """
        solution_path = []
        parent_node_dict = {self.__agent_position: None}
        true_cost_dict = {self.__agent_position: 0}
        heapq.heappush(self.__fringe, (self.__heuristic_map[self.__agent_position], self.__agent_position))
        self.__num_created += 1
        self.__max_fringe = len(self.__fringe)

        while self.__fringe:
            current_node = heapq.heappop(self.__fringe)[1]

            if current_node not in self.__expanded_nodes:
                self.__expanded_nodes.add(current_node)
                self.__num_expanded += 1

                if current_node == self.__goal_position:
                    while current_node is not None:
                        solution_path.append(current_node)
                        current_node = parent_node_dict[current_node]
                    solution_path.reverse()
                    self.__depth = len(solution_path)
                    self.__solution_path = solution_path
                    return self.__solution_path

                for direction, status in self.__maze_map[current_node].items():
                    if status == 1:
                        adjacent_node = self.adjacent(current_node, direction)

                        temporary_cost = true_cost_dict[current_node] + 1

                        if adjacent_node not in true_cost_dict or temporary_cost < true_cost_dict[adjacent_node]:
                            parent_node_dict[adjacent_node] = current_node
                            true_cost_dict[adjacent_node] = temporary_cost

                            f_score = temporary_cost + self.__heuristic_map[adjacent_node]
                            heapq.heappush(self.__fringe, (f_score, adjacent_node))
                            self.__num_created += 1

                            if len(self.__fringe) > self.__max_fringe:
                                self.__max_fringe = len(self.__fringe)

        return self.__solution_path

    @staticmethod
    def adjacent(current, direction) -> tuple[int, int]:
        """
        Computes the adjacent node from the given direction.

        Returns:
            A tuple that is the position of the calculated adjacent node.
        """
        adjacent = None
        if direction == "E":
            adjacent = (current[0], current[1] + 1)
        elif direction == "W":
            adjacent = (current[0], current[1] - 1)
        elif direction == "N":
            adjacent = (current[0] - 1, current[1])
        elif direction == "S":
            adjacent = (current[0] + 1, current[1])
        return adjacent

    def heuristics(self) -> dict[tuple[int, int], int]:
        """
        Computes the Manhattan distance heuristics for each position in the maze
        with respect to the goal position.

        Returns:
            A dictionary where the keys are positions in the maze
            and the values are the Manhattan distances to the goal position.
        """
        heuristics_map = {}

        for pos in self.__maze_grid:
            heuristic = abs((self.__goal_position[0] - pos[0])) + abs((self.__goal_position[1] - pos[1]))
            heuristics_map[pos] = heuristic

        return heuristics_map
