import pymaze as maze
import random
import sys

from SearchSolution import SearchSolution


def main():
    """Driver function to start the program."""
    M = int(sys.argv[1])  # argument for number of rows
    N = int(sys.argv[2])  # argument for number of columns
    SEARCH_METHOD = sys.argv[3]  # argument for search method

    AGENT, MAZE = create_maze_and_agent(M, N)

    # returns a solution to the goal, if there exists one, as a string of movement directions
    solution = SearchSolution(MAZE, AGENT, SEARCH_METHOD)
    solution_path = solution.search()
    solution_evaluation = solution.evaluate()

    # writes evaluation results to Readme.txt
    file = open("Readme.txt", "a")
    file.write(f"[{M}x{N}][{SEARCH_METHOD}]: "
               f"[depth: {solution_evaluation['depth']}], "
               f"[numCreated: {solution_evaluation['numCreated']}], "
               f"[numExpanded: {solution_evaluation['numExpanded']}], "
               f"[maxFringe: {solution_evaluation['maxFringe']}]\n")
    file.close()

    # runs the program with traced solution path
    MAZE.tracePath({AGENT: solution_path}, delay=100, showMarked=True)
    MAZE.run()


def create_maze_and_agent(row, column):
    """Helper function to create and configure the maze and agent according to the assignment's requirement.

    Returns:
        A maze and an agent object with the required settings
    """
    # random coordinates for goal
    goal_random_row, goal_random_column = random.randint(1, row), random.randint(1, column)
    # re-randomize the coordinates of agent if they match with those of the goal
    a_row, a_column = random.randint(1, row), random.randint(1, column)
    while a_row == goal_random_row and a_column == goal_random_column:
        a_row, a_column = random.randint(1, row), random.randint(1, column)
    # creates a maze of size MxN with a goal and an agent at random positions
    m = maze.maze(row, column)
    m.CreateMaze(goal_random_row, goal_random_column, theme=maze.COLOR.light, loopPercent=100)
    a = maze.agent(m, a_row, a_column, color=maze.COLOR.red, footprints=True)

    return a, m


########################################################################################################################

main()
