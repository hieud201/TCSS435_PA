
[20x30][BFS]: [depth: 37], [numCreated: 1560], [numExpanded: 584], [maxFringe: 78]
[50x50][BFS]: [depth: 18], [numCreated: 799], [numExpanded: 299], [maxFringe: 89]
[20x30][DFS]: [depth: 282], [numCreated: 1024], [numExpanded: 375], [maxFringe: 333]
[50x50][DFS]: [depth: 495], [numCreated: 6293], [numExpanded: 2347], [maxFringe: 1195]
[20x30][GS]: [depth: 14], [numCreated: 30], [numExpanded: 15], [maxFringe: 16]
[50x50][GS]: [depth: 46], [numCreated: 95], [numExpanded: 51], [maxFringe: 45]
[20x30][AStar]: [depth: 33], [numCreated: 155], [numExpanded: 114], [maxFringe: 39]
[50x50][AStar]: [depth: 29], [numCreated: 182], [numExpanded: 128], [maxFringe: 56]
