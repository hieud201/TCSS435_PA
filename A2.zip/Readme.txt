[10][MM]: 
[depth: 3], 
[nodes expanded: 298], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[20][MM]:
[depth: 3], 
[nodes expanded: 1898], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[10][MM]: 
[depth: 5], 
[nodes expanded: 4883], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[20][MM]: 
[depth: 5], 
[nodes expanded: 18065], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[10][AB]: 
[depth: 3], 
[nodes expanded: 206], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[20][AB]: 
[depth: 3], 
[nodes expanded: 652], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[10][AB]: 
[depth: 5], 
[nodes expanded: 1484], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]

[20][AB]: 
[depth: 5], 
[nodes expanded: 1630], 
[evaluation function: If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path cost using A*) 
If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path cost using A*)]
