import random
import sys

import pymaze as maze
from GameSearch import GameSearch

MAZE: maze.maze = None
GAME_SOLUTION: GameSearch = None
AI_AGENT: maze.agent = None
HUMAN_AGENT: maze.agent = None
previous_position: tuple[int, int] = None
SEARCH_METHOD: str = ''
SIZE: int = 0


def main():
    """Driver function to start the program."""
    global MAZE, GAME_SOLUTION, AI_AGENT, HUMAN_AGENT, SEARCH_METHOD, SIZE
    AI_NUMBER = int(sys.argv[1])
    SEARCH_METHOD = sys.argv[2]
    SIZE = int(sys.argv[3])

    HUMAN_AGENT, AI_AGENT, MAZE = create_maze_and_agents(SIZE)
    GAME_SOLUTION = GameSearch(MAZE, HUMAN_AGENT, AI_AGENT, AI_NUMBER, 5, SEARCH_METHOD)
    if AI_NUMBER == 1:
        MAZE.tracePath({AI_AGENT: GAME_SOLUTION.search()}, showMarked=True)
    MAZE.run()


def create_maze_and_agents(size: int) -> tuple[maze.agent, maze.agent, maze.maze]:
    """Helper function to create and configure the maze and agents according to the assignment's requirement.

    Returns:
        A maze with a goal and 2 agent objects with the required settings
    """
    row, column = 0, 0
    if size == 10:
        row, column = 10, 10
    elif size == 20:
        row, column = 20, 30

    goal_random_row, goal_random_column = random.randint(1, row), random.randint(1, column)

    human_agent_row, human_agent_column = random.randint(1, row), random.randint(1, column)
    while human_agent_row == goal_random_row and human_agent_column == goal_random_column:
        human_agent_row, human_agent_column = random.randint(1, row), random.randint(1, column)

    ai_agent_row, ai_agent_column = random.randint(1, row), random.randint(1, column)
    while ((ai_agent_row == goal_random_row and ai_agent_column == goal_random_column) or
           (ai_agent_row == human_agent_row and ai_agent_column == human_agent_column)):
        ai_agent_row, ai_agent_column = random.randint(1, row), random.randint(1, column)

    m = maze.maze(row, column)
    m.CreateMaze(goal_random_row, goal_random_column, theme=maze.COLOR.light, loopPercent=100)
    ai_agent = maze.agent(m, ai_agent_row, ai_agent_column, shape='arrow', color=maze.COLOR.blue, footprints=True)

    global previous_position
    human_agent = maze.agent(m, human_agent_row, human_agent_column, color=maze.COLOR.red, footprints=True)
    previous_position = human_agent.position
    m.enableArrowKey(human_agent, nextFunction=next_step)

    return human_agent, ai_agent, m


def next_step():
    """
    Checks if the human agent has moved and triggers the AI agent's move if necessary.

    This function monitors the human agent's position and, if it has changed since the last check,
    and neither agent has reached the goal, it initiates the AI agent's move using the `tracePath`
    method of the `MAZE` object.
    """
    global previous_position

    if HUMAN_AGENT.position != previous_position:
        previous_position = HUMAN_AGENT.position
        GAME_SOLUTION.human_agent_position(HUMAN_AGENT.position)

        if HUMAN_AGENT.position != MAZE._goal and AI_AGENT.position != MAZE._goal:
            MAZE.tracePath({AI_AGENT: GAME_SOLUTION.search()}, showMarked=True)
        else:
            MAZE.disableArrowKey()

            solution_evaluation = GAME_SOLUTION.evaluate()
            file = open("Readme.txt", "a")
            file.write(f"\n[{SIZE}][{SEARCH_METHOD}]: \n"
                       f"[depth: {solution_evaluation['depth']}], \n"
                       f"[nodes expanded: {solution_evaluation['nodes expanded']}], \n"
                       f"[evaluation function: {solution_evaluation['evaluation function']}]\n")
            file.close()


########################################################################################################################

main()
