import heapq
from typing import Any
from pymaze import maze, agent


class GameSearch:
    """
    A class used to represent a game search solution in a maze using different algorithms.

    This class takes a maze and 2 agents (human and AI) and applies a search method
    (Minimax, Alpha-beta Pruning Minimax) to find the optimal moves for the AI agent,
    which aims to reach the goal faster than the human agent.

    Attributes:
        __method: The search method to be used (MM - Minimax, AB - Alpha-Beta Pruning Minimax)
        __goal_position: The position of the goal
        __human_agent_position: The current position of the human agent
        __ai_agent_position: The current position of the AI agent
        __maze_map: The maze map, represented as a dictionary
                    where the keys are the cell positions and the values are
                    the information of the four walls of that cell in four directions
        __maze_grid: The grid of maze, represented as a list of cell positions
        __depth: The depth limit in the search tree
        __game_tree: The game tree of possible moves that either agents can make
        __num_expanded: The number of nodes expanded in the game tree
    """

    def __init__(self, m: maze, human_agent: agent, ai_agent: agent, ai_number: int, depth: int, method: str):
        """
        Constructs the necessary attributes for the GameSearch object.

        Args:
            m: The maze object.
            human_agent: The human agent.
            ai_agent: The AI agent that is used to predict its next optimal moves.
            ai_number: The AI agent's player number.
            depth: Depth of the game search tree.
            method: The search algorithm to be used. Should be one of the following:
                "MM": Minimax,
                "AB": Alpha-Beta Pruning Minimax

        Raises:
            ValueError: If the method provided is not one of the supported algorithms.
        """
        self.__method = method
        self.__goal_position = m._goal
        self.__human_agent_position = human_agent.position
        self.__ai_agent_position = ai_agent.position
        self.__ai_number = ai_number
        self.__maze_map = m.maze_map
        self.__maze_grid = m.grid
        self.__game_tree = []
        self.__depth = depth
        self.__num_expanded = 0

    def human_agent_position(self, position: tuple[int, int]):
        """
        Sets the human agent position.

        Args:
            position: The position for human agent.
        """
        self.__human_agent_position = position

    def search(self) -> list[tuple[int, int]]:
        """
        Performs the selected search algorithm to find the next optimal move.

        Returns:
            The list of tuples that are the initial position and the next optimal position of the agent .
        """
        if self.__ai_number == 1:
            initial_game_state = (self.__ai_agent_position, self.__human_agent_position, 0)

            self.__game_tree = self.__build_game_tree(
                self.__maze_map,
                initial_game_state,
                self.__depth,
                self.__ai_number
            )

            if self.__method == 'MM':
                new_ai_agent_position = \
                    self.__minimax_search(
                        self.__game_tree,
                        initial_game_state,
                        self.__depth,
                        self.__ai_number
                    )[1][0]
                solution_path = [self.__ai_agent_position, new_ai_agent_position]
                self.__ai_agent_position = new_ai_agent_position
                return solution_path
            elif self.__method == 'AB':
                new_ai_agent_position = \
                    self.__alpha_beta_search(
                        self.__game_tree,
                        initial_game_state,
                        self.__depth,
                        self.__ai_number,
                        float('-inf'),
                        float('inf')
                    )[1][0]
                solution_path = [self.__ai_agent_position, new_ai_agent_position]
                self.__ai_agent_position = new_ai_agent_position
                return solution_path
            else:
                raise ValueError("Invalid search method.")

        elif self.__ai_number == 2:
            initial_game_state = (self.__human_agent_position, self.__ai_agent_position, 0)

            self.__game_tree = self.__build_game_tree(
                self.__maze_map,
                initial_game_state,
                self.__depth,
                self.__ai_number
            )

            if self.__method == 'MM':
                new_ai_agent_position = \
                    self.__minimax_search(
                        self.__game_tree,
                        initial_game_state,
                        self.__depth,
                        self.__ai_number
                    )[1][1]
                solution_path = [self.__ai_agent_position, new_ai_agent_position]
                self.__ai_agent_position = new_ai_agent_position
                return solution_path
            elif self.__method == 'AB':
                new_ai_agent_position = \
                    self.__alpha_beta_search(
                        self.__game_tree,
                        initial_game_state,
                        self.__depth,
                        self.__ai_number,
                        float('-inf'),
                        float('inf')
                    )[1][1]
                solution_path = [self.__ai_agent_position, new_ai_agent_position]
                self.__ai_agent_position = new_ai_agent_position
                return solution_path
            else:
                raise ValueError("Invalid search method.")
        else:
            raise ValueError("Invalid AI player number.")

    def __minimax_search(self,
                         game_tree: list,
                         current_state: tuple[tuple[int, int], tuple[int, int], int],
                         depth: int,
                         agent_number: int
                         ) -> tuple[int, tuple[Any, Any]]:
        """
        Implements Minimax algorithm to find the optimal move for the AI.

        Args:
            game_tree: The game tree to be used for evaluating the optimal move.
            current_state: The current state of the game (current positions of both agents and a utility value)
            depth: The depth level of tree exploration
            agent_number: The agent player number

        Returns:
            The list of tuples that are the initial position and the next optimal position of the agent.
        """
        if depth == 0 or self.__is_terminal(current_state[:-1]):
            self.__num_expanded += 1
            return current_state[-1], current_state[:-1]

        if agent_number == 1:
            maximum_utility_value = float('-inf')
            optimal_move = None
            for possible_states in game_tree[game_tree.index(current_state) + 1:]:
                new_state = possible_states[0]
                self.__num_expanded += 1
                utility_value, _ = self.__minimax_search(possible_states, new_state, depth - 1, 3 - agent_number)
                if utility_value > maximum_utility_value:
                    maximum_utility_value = utility_value
                    optimal_move = new_state[:-1]
            return maximum_utility_value, optimal_move

        elif agent_number == 2:
            minimum_utility_value = float('inf')
            optimal_move = None
            for possible_states in game_tree[game_tree.index(current_state) + 1:]:
                new_state = possible_states[0]
                self.__num_expanded += 1
                utility_value, _ = self.__minimax_search(possible_states, new_state, depth - 1, 3 - agent_number)
                if utility_value < minimum_utility_value:
                    minimum_utility_value = utility_value
                    optimal_move = new_state[:-1]
            return minimum_utility_value, optimal_move

    def __alpha_beta_search(self,
                            game_tree: list,
                            current_state: tuple[tuple[int, int], tuple[int, int], int],
                            depth: int,
                            agent_number: int,
                            alpha: int,
                            beta: int
                            ) -> tuple[int, tuple[Any, Any]]:
        """
        Implements Alpha-Beta Pruning Minimax algorithm to find the optimal move for the AI.

        Args:
            game_tree: The game tree to be used for evaluating the optimal move.
            current_state: The current state of the game (current positions of both agents and a utility value)
            depth: The depth level of tree exploration
            agent_number: The agent player number
            alpha: The best utility value so far for agent player number 1
            beta: The best utility value so far for agent player number 2

        Returns:
            The list of tuples that are the initial position and the next optimal position of the agent.
        """
        if depth == 0 or self.__is_terminal(current_state[:-1]):
            self.__num_expanded += 1
            return current_state[-1], current_state[:-1]

        if agent_number == 1:
            maximum_utility_value = float('-inf')
            optimal_move = None
            for possible_move in game_tree[game_tree.index(current_state) + 1:]:
                new_state = possible_move[0]
                self.__num_expanded += 1
                utility_value, _ = self.__alpha_beta_search(
                    possible_move,
                    new_state,
                    depth - 1,
                    3 - agent_number,
                    alpha,
                    beta
                )
                maximum_utility_value = max(maximum_utility_value, utility_value)
                alpha = max(alpha, utility_value)
                if alpha >= beta:
                    break
                if utility_value == maximum_utility_value:
                    optimal_move = new_state[:-1]
            return maximum_utility_value, optimal_move

        elif agent_number == 2:
            minimum_utility_value = float('inf')
            optimal_move = None
            for possible_move in game_tree[game_tree.index(current_state) + 1:]:
                new_state = possible_move[0]
                self.__num_expanded += 1
                utility_value, _ = self.__alpha_beta_search(
                    possible_move,
                    new_state,
                    depth - 1,
                    3 - agent_number,
                    alpha,
                    beta
                )
                minimum_utility_value = min(minimum_utility_value, utility_value)
                beta = min(beta, utility_value)
                if alpha >= beta:
                    break
                if utility_value == minimum_utility_value:
                    optimal_move = new_state[:-1]
            return minimum_utility_value, optimal_move

    def __build_game_tree(self,
                          maze_map: dict,
                          current_state: tuple[tuple[int, int], tuple[int, int], int],
                          depth: int,
                          current_agent: int
                          ) -> list:
        """
        Builds a game tree for a two-agent maze game.

        Args:
            maze_map: The maze map as a dictionary
            current_state: A tuple representing the current game state (positions of both agents)
                and the state's utility value.
            depth: The maximum depth of the tree.
            current_agent: The agent whose turn it is 1 or 2.

        Returns:
            A list of lists representing the game tree.
        """
        if depth == 0 or self.__is_terminal(current_state[:-1]):
            return [current_state[:-1] + (self.__utility_value(current_state[:-1]),)]

        game_tree = [current_state]
        for direction, status in self.__maze_map[current_state[current_agent - 1]].items():
            if status == 1:
                new_position = self.__get_adjacent(current_state[current_agent - 1], direction)
                new_state = current_state[:current_agent - 1] + (new_position,) + current_state[current_agent:]
                game_tree.append(self.__build_game_tree(maze_map, new_state, depth - 1, 3 - current_agent))

        return game_tree

    def __is_terminal(self, current_state: tuple[tuple[int, int], tuple[int, int]]):
        """
        Checks if the current state is a terminal state.

        Args:
            current_state: A tuple representing the positions of both players.

        Returns:
            True if the current state is terminal (either agent has reached the goal), False otherwise.
        """
        return current_state[0] == self.__goal_position or current_state[1] == self.__goal_position

    @staticmethod
    def __get_adjacent(current_node: tuple[int, int], direction_to_explore: str) -> tuple[int, int]:
        """
        Computes the adjacent node from the given direction.

        Args:
            current_node: The node to be used to explore its adjacent node.
            direction_to_explore: The direction to explore.

        Returns:
            A tuple that is the position of the calculated adjacent node.
        """
        adjacent = None
        if direction_to_explore == "E":
            adjacent = (current_node[0], current_node[1] + 1)
        elif direction_to_explore == "W":
            adjacent = (current_node[0], current_node[1] - 1)
        elif direction_to_explore == "N":
            adjacent = (current_node[0] - 1, current_node[1])
        elif direction_to_explore == "S":
            adjacent = (current_node[0] + 1, current_node[1])
        return adjacent

    def __utility_value(self, current_state: tuple[tuple[int, int], tuple[int, int]]) -> float | int:
        """Evaluates the utility values of the leaf nodes in the game search tree
        using A star search as the underlying utility function.

        Args:
              current_state: The leaf node represented as a game state (positions of both agents).

        Returns:
              Utility value of the leaf node
        """

        def a_star(initial_position: tuple[int, int]) -> list[tuple[int, int]]:
            """
            Perform A* Graph Search on the maze.

            Args:
                  initial_position: The initial position of the agent.

            Returns:
                A list of cells representing the path found by the
                search algorithm from the start to the goal in the maze.
            """

            def heuristics() -> dict[tuple[int, int], int]:
                """
                Computes the Manhattan distance heuristics for each position in the maze
                with respect to the goal position.

                Returns:
                    A dictionary where the keys are positions in the maze
                    and the values are the Manhattan distances to the goal position.
                """
                heuristics_map = {}
                for pos in self.__maze_grid:
                    heuristic = abs((self.__goal_position[0] - pos[0])) + abs((self.__goal_position[1] - pos[1]))
                    heuristics_map[pos] = heuristic
                return heuristics_map

            fringe = []
            agent_position = initial_position
            heuristic_map = heuristics()
            expanded_nodes = set()
            solution_path = []
            parent_node_dict = {agent_position: None}
            true_cost_dict = {agent_position: 0}
            heapq.heappush(fringe, (heuristic_map[agent_position], agent_position))

            while fringe:
                current_node = heapq.heappop(fringe)[1]

                if current_node not in expanded_nodes:
                    expanded_nodes.add(current_node)

                    if current_node == self.__goal_position:
                        while current_node is not None:
                            solution_path.append(current_node)
                            current_node = parent_node_dict[current_node]
                        solution_path.reverse()
                        return solution_path

                    for direction, status in self.__maze_map[current_node].items():
                        if status == 1:
                            adjacent_node = self.__get_adjacent(current_node, direction)

                            temporary_cost = true_cost_dict[current_node] + 1

                            if adjacent_node not in true_cost_dict or temporary_cost < true_cost_dict[adjacent_node]:
                                parent_node_dict[adjacent_node] = current_node
                                true_cost_dict[adjacent_node] = temporary_cost

                                f_score = temporary_cost + heuristic_map[adjacent_node]
                                heapq.heappush(fringe, (f_score, adjacent_node))

            return solution_path

        if self.__is_terminal(current_state):
            if self.__ai_number == 1:
                if current_state[0] == self.__goal_position:
                    return float('inf')
                elif current_state[1] == self.__goal_position:
                    return float('-inf')
            elif self.__ai_number == 2:
                if current_state[0] == self.__goal_position:
                    return float('-inf')
                elif current_state[1] == self.__goal_position:
                    return float('inf')
        else:
            if self.__ai_number == 1:
                ai_optimal_path_cost = len(a_star(current_state[0]))
                human_optimal_path_cost = len(a_star(current_state[1]))
                return -ai_optimal_path_cost + human_optimal_path_cost
            elif self.__ai_number == 2:
                ai_optimal_path_cost = len(a_star(current_state[1]))
                human_optimal_path_cost = len(a_star(current_state[0]))
                return ai_optimal_path_cost - human_optimal_path_cost

    def evaluate(self) -> dict[str, Any]:
        """
        Returns an evaluation of the search algorithm by collecting the following metrics:
        depth of game search tree and number of nodes expanded,
        and evaluation function for calculating the utility value of non-terminal leaf nodes.

        Returns:
            A dictionary containing the evaluation metrics.
        """
        return {
            'depth': self.__depth,
            'nodes expanded': self.__num_expanded,
            'evaluation function': 'If AI player number is 1: -(AI optimal path cost using A*) + (Human optimal path '
                                   'cost using A*) \n'
                                   'If AI player number is 2: (AI optimal path cost using A*) - (Human optimal path '
                                   'cost using A*)'
        }
